# Zero One ERP – Full-stack starter

A starter foundation for a construction and real-estate ERP:
- Frontend: Next.js App Router + TypeScript + Tailwind CSS
- Backend: NestJS + Prisma
- Database: PostgreSQL (Docker Compose)
- First working features: ERP dashboard metrics and project CRUD API

## Requirements
- Node.js 20.9+ (Node 22 LTS recommended)
- npm
- Docker Desktop (or a local PostgreSQL 15+ server)

## 1. Start PostgreSQL
From this folder:
```bash
docker compose up -d
```

PostgreSQL is exposed on `localhost:5432`.
Default local development credentials are in `backend/.env.example`.
Change them for any shared or production environment.

## 2. Configure and start the backend
```bash
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run start:dev
```
Backend: http://localhost:4000/api
Swagger docs: http://localhost:4000/api/docs

## 3. Start the frontend
Open a second terminal:
```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```
Frontend: http://localhost:3000

## 4. Verify
- Open http://localhost:3000
- The dashboard calls `GET http://localhost:4000/api/dashboard/summary`
- Swagger: `http://localhost:4000/api/docs`
- Create a project using `POST /api/projects`

Example POST body:
```json
{
  "name": "Dubai Residential Tower",
  "location": "Dubai, UAE",
  "budget": 25000000,
  "description": "Residential apartment development"
}
```

## Project layout
```text
zero-one-erp/
├── docker-compose.yml
├── README.md
├── backend/
│   ├── prisma/schema.prisma
│   ├── src/
│   │   ├── dashboard/
│   │   ├── prisma/
│   │   └── projects/
│   ├── .env.example
│   └── package.json
└── frontend/
    ├── src/app/
    ├── src/components/
    ├── src/lib/
    ├── .env.local.example
    └── package.json
```

## Important next steps before production
This is a development starter, not a production-ready ERP. Before real client data:
1. Add authentication, refresh-token handling, RBAC and audit logs.
2. Add DTO validation and authorization to every write endpoint.
3. Add transactional booking logic and prevent double-booking at database level.
4. Add finance/accounting controls, backups, monitoring and security testing.
5. Review UAE VAT, privacy, real-estate and project-specific regulatory requirements with qualified advisers.
6. Use managed secrets, private database networking, HTTPS and separate staging/production environments.
