import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DashboardService {
  constructor(private readonly prisma: PrismaService) {}

  async getSummary() {
    const [totalProjects, activeProjects, totalBuildings, totalUnits, availableUnits] =
      await Promise.all([
        this.prisma.project.count(),
        this.prisma.project.count({ where: { status: 'ACTIVE' } }),
        this.prisma.building.count(),
        this.prisma.unit.count(),
        this.prisma.unit.count({ where: { status: 'AVAILABLE' } }),
      ]);

    const recentProjects = await this.prisma.project.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        location: true,
        status: true,
        budget: true,
        createdAt: true,
        _count: { select: { buildings: true } },
      },
    });

    return {
      metrics: {
        totalProjects,
        activeProjects,
        totalBuildings,
        totalUnits,
        availableUnits,
      },
      recentProjects,
    };
  }
}
