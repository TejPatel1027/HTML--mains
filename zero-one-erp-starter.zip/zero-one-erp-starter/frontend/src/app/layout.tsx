import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Zero One ERP | Builder & Construction Management',
  description: 'Business management platform for Zero One Builder & Constructions.',
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
