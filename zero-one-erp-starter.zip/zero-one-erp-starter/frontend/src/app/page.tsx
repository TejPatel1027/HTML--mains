'use client';

import { useEffect, useState } from 'react';
import {
  ArrowDownRight, ArrowUpRight, Bell, Building2, CalendarDays,
  ChevronDown, CircleDollarSign, HardHat, Menu, Plus, Search,
  Users, WalletCards, RefreshCw, AlertCircle
} from 'lucide-react';
import { Sidebar } from '@/components/sidebar';
import { DashboardSummary, getDashboardSummary, Project } from '@/lib/api';

function money(value: string | number) {
  return new Intl.NumberFormat('en-AE', {
    style: 'currency',
    currency: 'AED',
    maximumFractionDigits: 0,
  }).format(Number(value));
}

function StatusPill({ status }: { status: string }) {
  const styles: Record<string, string> = {
    ACTIVE: 'bg-emerald-50 text-emerald-700',
    PLANNING: 'bg-amber-50 text-amber-700',
    ON_HOLD: 'bg-slate-100 text-slate-600',
    COMPLETED: 'bg-blue-50 text-blue-700',
    CANCELLED: 'bg-rose-50 text-rose-700',
  };
  return <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${styles[status] ?? 'bg-slate-100 text-slate-600'}`}>{status.replace('_', ' ')}</span>;
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function loadDashboard() {
    setLoading(true);
    setError('');
    try {
      const result = await getDashboardSummary();
      setData(result);
    } catch {
      setError('Could not connect to the ERP API. Check that PostgreSQL and the backend are running.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadDashboard(); }, []);

  const metrics = [
    { label: 'Total Projects', value: data?.metrics.totalProjects ?? '—', note: 'Across the company', icon: Building2, color: 'bg-blue-50 text-blue-700' },
    { label: 'Active Projects', value: data?.metrics.activeProjects ?? '—', note: 'Currently in progress', icon: HardHat, color: 'bg-emerald-50 text-emerald-700' },
    { label: 'Total Buildings', value: data?.metrics.totalBuildings ?? '—', note: 'Registered buildings', icon: Building2, color: 'bg-violet-50 text-violet-700' },
    { label: 'Available Units', value: data?.metrics.availableUnits ?? '—', note: `${data?.metrics.totalUnits ?? 0} total units`, icon: Users, color: 'bg-amber-50 text-amber-700' },
  ];

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:block"><Sidebar /></div>
      <main className="min-w-0 flex-1">
        <header className="h-[86px] bg-white border-b border-slate-200 px-5 lg:px-9 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="lg:hidden rounded-lg bg-slate-100 p-2"><Menu className="h-5 w-5" /></div>
            <div>
              <div className="text-xs text-slate-400">Workspace / Overview</div>
              <h1 className="text-xl font-bold text-slate-900">Dashboard</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-400">
              <Search className="h-4 w-4" /> Search anything...
              <span className="ml-8 rounded bg-slate-100 px-1.5 py-0.5 text-[10px]">⌘ K</span>
            </div>
            <button className="relative rounded-xl border border-slate-200 p-2.5 text-slate-600"><Bell className="h-4 w-4" /><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-rose-500" /></button>
            <div className="flex items-center gap-2 border-l border-slate-200 pl-3">
              <div className="h-9 w-9 rounded-full bg-[#dce8ff] text-blue-800 flex items-center justify-center text-xs font-bold">ZO</div>
              <div className="hidden sm:block"><div className="text-xs font-semibold">Administrator</div><div className="text-[10px] text-slate-400">Super Admin</div></div>
              <ChevronDown className="hidden sm:block h-4 w-4 text-slate-400" />
            </div>
          </div>
        </header>

        <div className="p-5 lg:p-9 max-w-[1600px] mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-7">
            <div>
              <p className="text-sm text-slate-500">Welcome back, Administrator</p>
              <h2 className="mt-1 text-2xl lg:text-[28px] font-bold tracking-tight text-slate-900">Business overview</h2>
              <p className="mt-1 text-sm text-slate-500">Monitor projects, properties and operations from one place.</p>
            </div>
            <div className="flex gap-2">
              <button onClick={loadDashboard} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                <RefreshCw className="h-4 w-4" /> Refresh
              </button>
              <a href="/projects" className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700">
                <Plus className="h-4 w-4" /> New project
              </a>
            </div>
          </div>

          {error && <div className="mb-5 flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800"><AlertCircle className="h-5 w-5 shrink-0" />{error}</div>}

          <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
            {metrics.map((metric) => {
              const Icon = metric.icon;
              return <div key={metric.label} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_2px_10px_rgba(15,23,42,.03)]">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">{metric.label}</span>
                  <span className={`rounded-xl p-2.5 ${metric.color}`}><Icon className="h-5 w-5" /></span>
                </div>
                <div className="mt-4 text-3xl font-bold tracking-tight text-slate-900">{loading ? '…' : metric.value}</div>
                <div className="mt-2 text-xs text-slate-400">{metric.note}</div>
              </div>;
            })}
          </section>

          <section className="grid grid-cols-1 xl:grid-cols-3 gap-5 mb-6">
            <div className="xl:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 lg:p-6">
              <div className="flex items-center justify-between mb-5">
                <div><h3 className="font-bold text-slate-900">Recent projects</h3><p className="mt-1 text-xs text-slate-400">Latest projects registered in the ERP</p></div>
                <a href="/projects" className="text-xs font-semibold text-blue-600 hover:text-blue-700">View all</a>
              </div>
              {loading ? <div className="py-12 text-center text-sm text-slate-400">Loading projects...</div> :
                data?.recentProjects.length ? <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead><tr className="border-b border-slate-100 text-[11px] uppercase tracking-wider text-slate-400"><th className="pb-3 font-semibold">Project</th><th className="pb-3 font-semibold">Location</th><th className="pb-3 font-semibold">Buildings</th><th className="pb-3 font-semibold">Budget</th><th className="pb-3 font-semibold">Status</th></tr></thead>
                    <tbody>{data.recentProjects.map((project: Project) => <tr key={project.id} className="border-b border-slate-50 last:border-0">
                      <td className="py-4 pr-3"><div className="text-sm font-semibold text-slate-800">{project.name}</div><div className="text-[11px] text-slate-400">Project #{project.id}</div></td>
                      <td className="py-4 pr-3 text-xs text-slate-500">{project.location}</td>
                      <td className="py-4 pr-3 text-xs text-slate-600">{project._count?.buildings ?? 0}</td>
                      <td className="py-4 pr-3 text-xs font-semibold text-slate-700">{money(project.budget)}</td>
                      <td className="py-4"><StatusPill status={project.status} /></td>
                    </tr>)}</tbody>
                  </table>
                </div> : <div className="py-12 text-center"><Building2 className="mx-auto h-8 w-8 text-slate-300" /><p className="mt-3 text-sm font-medium text-slate-600">No projects yet</p><p className="mt-1 text-xs text-slate-400">Create your first project to see it here.</p><a href="/projects" className="mt-4 inline-flex rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white">Create project</a></div>}
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 lg:p-6">
              <h3 className="font-bold text-slate-900">Quick actions</h3>
              <p className="mt-1 text-xs text-slate-400">Common management tasks</p>
              <div className="mt-5 space-y-3">
                {[
                  { icon: Building2, title: 'Add a project', desc: 'Register a new development', href: '/projects', color: 'text-blue-600 bg-blue-50' },
                  { icon: Users, title: 'Add a customer', desc: 'Create a customer profile', href: '/customers', color: 'text-violet-600 bg-violet-50' },
                  { icon: WalletCards, title: 'Record a payment', desc: 'Track a customer transaction', href: '/finance', color: 'text-emerald-600 bg-emerald-50' },
                  { icon: HardHat, title: 'Site progress', desc: 'Update construction activity', href: '/construction', color: 'text-amber-600 bg-amber-50' },
                ].map((action) => {
                  const Icon = action.icon;
                  return <a key={action.title} href={action.href} className="flex items-center gap-3 rounded-xl border border-slate-100 p-3 hover:border-blue-200 hover:bg-blue-50/30">
                    <span className={`rounded-lg p-2 ${action.color}`}><Icon className="h-4 w-4" /></span>
                    <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-slate-800">{action.title}</span><span className="block text-[11px] text-slate-400">{action.desc}</span></span>
                    <Plus className="h-4 w-4 text-slate-400" />
                  </a>;
                })}
              </div>
            </div>
          </section>

          <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-2xl bg-[#172b4d] p-5 text-white md:col-span-2">
              <div className="flex items-start justify-between"><div><div className="text-xs text-blue-200">ERP OPERATIONS</div><h3 className="mt-2 text-xl font-bold">One platform. Every project.</h3><p className="mt-2 max-w-lg text-sm leading-6 text-slate-300">Connect project delivery, property sales, procurement and finance with a single operational workspace.</p></div><div className="rounded-xl bg-white/10 p-3"><Building2 className="h-6 w-6" /></div></div>
              <div className="mt-6 flex flex-wrap gap-2"><span className="rounded-full bg-white/10 px-3 py-1.5 text-xs">Project control</span><span className="rounded-full bg-white/10 px-3 py-1.5 text-xs">Property inventory</span><span className="rounded-full bg-white/10 px-3 py-1.5 text-xs">Sales operations</span><span className="rounded-full bg-white/10 px-3 py-1.5 text-xs">Financial visibility</span></div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5">
              <div className="flex items-center gap-2 text-slate-500"><CalendarDays className="h-4 w-4" /><span className="text-xs font-semibold">SYSTEM STATUS</span></div>
              <div className="mt-4 flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full bg-emerald-500" /><span className="text-sm font-semibold text-slate-800">{error ? 'API disconnected' : loading ? 'Checking connection' : 'Dashboard connected'}</span></div>
              <p className="mt-2 text-xs leading-5 text-slate-400">Live project data is loaded from the ERP backend.</p>
            </div>
          </section>

          <footer className="mt-8 flex flex-col sm:flex-row justify-between gap-2 text-[11px] text-slate-400">
            <span>© {new Date().getFullYear()} Zero One Builder & Constructions</span>
            <span>ERP development environment · Version 1.0</span>
          </footer>
        </div>
      </main>
    </div>
  );
}
