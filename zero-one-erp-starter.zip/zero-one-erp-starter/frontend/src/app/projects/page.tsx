'use client';

import { FormEvent, useEffect, useState } from 'react';
import { Plus, RefreshCw, MapPin, Building2 } from 'lucide-react';
import { Sidebar } from '@/components/sidebar';
import { Project } from '@/lib/api';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api';

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [form, setForm] = useState({ name: '', location: '', budget: '', description: '' });

  async function load() {
    setLoading(true);
    try {
      const response = await fetch(`${API}/projects`, { cache: 'no-store' });
      if (!response.ok) throw new Error('Could not load projects');
      setProjects(await response.json());
    } catch (e) {
      setMessage('Unable to load projects. Check the backend connection.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setMessage('');
    try {
      const response = await fetch(`${API}/projects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, budget: Number(form.budget) }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message ?? 'Project could not be created');
      setForm({ name: '', location: '', budget: '', description: '' });
      setMessage('Project created successfully.');
      await load();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Something went wrong.');
    }
  }

  return <div className="min-h-screen flex">
    <div className="hidden lg:block"><Sidebar /></div>
    <main className="flex-1 min-w-0">
      <header className="h-[86px] bg-white border-b border-slate-200 px-8 flex items-center"><div><p className="text-xs text-slate-400">Workspace / Projects</p><h1 className="text-xl font-bold">Project management</h1></div></header>
      <div className="max-w-[1400px] mx-auto p-5 lg:p-9">
        <div className="flex justify-between items-center mb-6"><div><h2 className="text-2xl font-bold">Projects</h2><p className="text-sm text-slate-500 mt-1">Create and manage construction developments.</p></div><button onClick={load} className="flex items-center gap-2 border rounded-xl bg-white px-4 py-2 text-sm"><RefreshCw className="h-4 w-4" /> Refresh</button></div>
        {message && <p className="mb-4 rounded-lg bg-blue-50 p-3 text-sm text-blue-800">{message}</p>}
        <div className="grid grid-cols-1 xl:grid-cols-[360px_1fr] gap-5">
          <form onSubmit={submit} className="h-fit rounded-2xl border border-slate-200 bg-white p-5">
            <h3 className="font-bold mb-4">Create new project</h3>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Project name</label>
            <input required minLength={2} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full rounded-lg border p-3 text-sm mb-3" placeholder="e.g. Dubai Residential Tower" />
            <label className="block text-xs font-semibold text-slate-600 mb-1">Location</label>
            <input required value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} className="w-full rounded-lg border p-3 text-sm mb-3" placeholder="Dubai, UAE" />
            <label className="block text-xs font-semibold text-slate-600 mb-1">Budget (AED)</label>
            <input required type="number" min="0" step="0.01" value={form.budget} onChange={e => setForm({ ...form, budget: e.target.value })} className="w-full rounded-lg border p-3 text-sm mb-3" placeholder="25000000" />
            <label className="block text-xs font-semibold text-slate-600 mb-1">Description</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="w-full rounded-lg border p-3 text-sm mb-4" rows={3} placeholder="Project details..." />
            <button className="w-full flex justify-center items-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-700"><Plus className="h-4 w-4" /> Create project</button>
          </form>
          <section className="rounded-2xl border border-slate-200 bg-white p-5">
            <h3 className="font-bold mb-4">Registered projects</h3>
            {loading ? <p className="text-sm text-slate-400 py-8">Loading...</p> : projects.length === 0 ? <div className="text-center py-12"><Building2 className="mx-auto text-slate-300" /><p className="mt-2 text-sm text-slate-500">No projects have been created yet.</p></div> :
              <div className="space-y-3">{projects.map(project => <div key={project.id} className="rounded-xl border border-slate-100 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div><div className="font-semibold text-slate-800">{project.name}</div><div className="mt-1 flex items-center gap-1 text-xs text-slate-400"><MapPin className="h-3 w-3" />{project.location}</div></div>
                <div className="flex items-center gap-5"><div><div className="text-[10px] uppercase text-slate-400">Budget</div><div className="text-sm font-semibold">{Number(project.budget).toLocaleString('en-AE')} AED</div></div><span className="rounded-full bg-slate-100 px-3 py-1 text-[10px] font-bold">{project.status}</span></div>
              </div>)}</div>}
          </section>
        </div>
      </div>
    </main>
  </div>;
}
