'use client';

import Link from 'next/link';
import {
  Activity, Building2, BriefcaseBusiness, ChevronLeft,
  ClipboardList, FileText, LayoutDashboard, Settings,
  Users, Wallet, HardHat, Package, ContactRound
} from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { label: 'Dashboard', href: '/', icon: LayoutDashboard },
  { label: 'Projects', href: '/projects', icon: BriefcaseBusiness },
  { label: 'Properties', href: '/properties', icon: Building2 },
  { label: 'CRM & Customers', href: '/customers', icon: ContactRound },
  { label: 'Sales & Bookings', href: '/bookings', icon: ClipboardList },
  { label: 'Construction', href: '/construction', icon: HardHat },
  { label: 'Procurement', href: '/procurement', icon: Package },
  { label: 'Finance', href: '/finance', icon: Wallet },
  { label: 'HR & Employees', href: '/employees', icon: Users },
  { label: 'Documents', href: '/documents', icon: FileText },
  { label: 'Reports', href: '/reports', icon: Activity },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside className={`${collapsed ? 'w-[84px]' : 'w-[264px]'} min-h-screen bg-[#111c30] text-white flex flex-col transition-all duration-200`}>
      <div className="h-[86px] px-5 flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="h-10 w-10 shrink-0 rounded-xl bg-blue-500 flex items-center justify-center font-black">ZO</div>
          {!collapsed && <div className="min-w-0"><div className="font-bold tracking-wide">ZERO ONE</div><div className="text-[10px] text-slate-400 tracking-[.18em]">BUILDER ERP</div></div>}
        </div>
        <button onClick={() => setCollapsed(!collapsed)} className="text-slate-400 hover:text-white" aria-label="Toggle sidebar">
          <ChevronLeft className={`h-4 w-4 transition-transform ${collapsed ? 'rotate-180' : ''}`} />
        </button>
      </div>

      <div className="px-4 pt-6 pb-2 text-[10px] uppercase tracking-[.2em] text-slate-500">
        {!collapsed && 'Workspace'}
      </div>
      <nav className="px-3 space-y-1">
        {navItems.map(({ label, href, icon: Icon }, index) => (
          <Link key={href} href={href} title={collapsed ? label : undefined}
            className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm ${index === 0 ? 'bg-blue-600 text-white shadow-lg shadow-blue-950/30' : 'text-slate-300 hover:bg-white/10 hover:text-white'}`}>
            <Icon className="h-[18px] w-[18px] shrink-0" />
            {!collapsed && <span>{label}</span>}
          </Link>
        ))}
      </nav>

      <div className="mt-auto p-3">
        <Link href="/settings" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-slate-300 hover:bg-white/10">
          <Settings className="h-[18px] w-[18px]" />
          {!collapsed && 'Settings'}
        </Link>
        {!collapsed && <div className="mt-3 rounded-xl border border-white/10 bg-white/5 p-3">
          <div className="text-xs font-semibold">Zero One ERP</div>
          <div className="mt-1 text-[11px] text-slate-400">Development environment</div>
        </div>}
      </div>
    </aside>
  );
}
