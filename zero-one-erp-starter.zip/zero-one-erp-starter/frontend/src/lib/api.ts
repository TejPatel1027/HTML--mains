const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api';

export type Project = {
  id: number;
  name: string;
  location: string;
  status: string;
  budget: string | number;
  createdAt: string;
  _count?: { buildings: number };
};

export type DashboardSummary = {
  metrics: {
    totalProjects: number;
    activeProjects: number;
    totalBuildings: number;
    totalUnits: number;
    availableUnits: number;
  };
  recentProjects: Project[];
};

export async function getDashboardSummary(): Promise<DashboardSummary> {
  const response = await fetch(`${API_URL}/dashboard/summary`, {
    cache: 'no-store',
  });

  if (!response.ok) {
    throw new Error(`Dashboard API returned ${response.status}`);
  }

  return response.json();
}
